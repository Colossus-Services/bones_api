#!/bin/bash

BIN_GEN_TABLES="bin/generate_tables_sql.dart"

echo "Generating tables SQL for PostgreSQL..."
dart run $BIN_GEN_TABLES api-local-postgres.yaml > db-tables-postgres-generated.sql

echo "Generating tables SQL for MySQL..."
dart run $BIN_GEN_TABLES api-local-mysql.yaml > db-tables-mysql-generated.sql

echo "** SQL Files:"
ls -alh *.sql | grep generated
