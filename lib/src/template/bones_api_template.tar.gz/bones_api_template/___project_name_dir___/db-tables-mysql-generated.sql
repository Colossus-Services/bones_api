-- API: ___project_name_dir___[1.0.0]
-- SQLAdapter: MySQLAdapter
-- Dialect: MySQL
-- Generator: BonesAPI/1.2.22

-- Entity: Address @ address

CREATE TABLE IF NOT EXISTS `address` (
 `id` SERIAL PRIMARY KEY,         -- int id
 `address_line_1` VARCHAR(1024),  -- String addressLine1
 `address_line_2` VARCHAR(1024),  -- String addressLine2
 `city` VARCHAR(128),             -- String city
 `country_code` VARCHAR(3),       -- String countryCode
 `state` VARCHAR(1024),           -- String state
 `zip_code` VARCHAR(1024)         -- String zipCode 
) ;

-- Entity: Account @ account

CREATE TABLE IF NOT EXISTS `account` (
 `id` SERIAL PRIMARY KEY,        -- int id
 `address` BIGINT UNSIGNED,      -- Address address @ address.id
 `creation_time` TIMESTAMP,      -- DateTime creationTime
 `email` VARCHAR(200),           -- String email
 `password_hash` VARCHAR(1024),  -- String passwordHash
 CONSTRAINT `account__email__unique` UNIQUE (`email`),
 CONSTRAINT `account__address__fkey` FOREIGN KEY (`address`) REFERENCES `address`(`id`) ON UPDATE CASCADE  -- address @ address.id 
) ;


