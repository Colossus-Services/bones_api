# ___project_name___

___project_description___

## Serving the API

To serve the API in this project:

- Go to the project directory:
  ```shell
  cd /path/to/___project_name_dir___
  ```

- Get the project dependencies:
  ```shell
  dart pub get
  ```

- Serve the API through `APIServer` (HTTP Server):
  ```shell
  bones_api serve -d . -c MyAPIRoot -b -i api-local.yaml
  ```
  - "-d": The directory of the project.
  - "-c": The `APIRoot` class name to serve.
  - "-b": Allows automatic reflection build if the inspector detects the need at startup.
  - "-i": API Configuration file.

The `bones_api serve` output should finish with something similar to:

```text
...

** APIServer Started.

APIServer{ apiType: MyAPIRoot, apiRoot: ___project_name_dir___[1.0.0]{info, account}, address: localhost, port: 8080, hotReload: false, started: true, stopped: false }

URL: http://localhost:8080/
```

## APIConfig

To instantiate an `APIRoot` implementation you can pass a configuration file or JSON/YAML
to be the `APIConfig`.

Example:
```yaml

db:
  postgres:
    host: dev.server.domain
    port: 5432
    database: dev_postgres
    username: postgres
    password: 123456
    populate:
      generateTables: true
      source: db-samples-1.json

```

The example above will connect to a PostgreSQL DB at `dev.server.domain` with
username `postgres` and password `123456`. Then it will create the tables with
auto generated SQL and populate them with the entities at `db-samples-1.json`.

To run a Docker container for the example above:

```shel
$> docker run --name dev_postgres --rm -p 5432:5432 -e POSTGRES_PASSWORD=123456 -e POSTGRES_USER=postgres -e POSTGRES_DB=dev_postgres -d postgres
```

See some examples of configuration files:

- `api-local-dev-postgres.yaml`
- `api-local-dev-mysql.yaml`
- `api-local-dev-memory.yaml`
- `api-local-postgres.yaml`
- `api-local-mysql.yaml`

## PostgreSQL Docker Container

This project needs a database and the `APIEntityRepositoryProvider` class
is using a `PostgreSQL` adapter.

To run a local `PostgreSQL` with Docker you can run the command:

```shell
docker run --name myapi-postgres -p 5432:5432 -e POSTGRES_PASSWORD=123456 -e POSTGRES_USER=postgres -e POSTGRES_DB=postgres -d postgres
```

The parameters above should be compatible with the configuration file `api-local.yaml`.


To connect to the DB using the psql client:

```shell
docker exec -it myapi-postgres /usr/bin/psql -U postgres
```

This will show the `psql` console.

To list the current tables you can use the command `\d`:

```
postgres=# \d
Did not find any relations.
```

- Nothe that a fresh database won't have any table.

Then you can create the tables used in this project:

```sql

-- Entity: Address @ address

CREATE TABLE IF NOT EXISTS "address" (
  "id" SERIAL PRIMARY KEY,    -- int id
  "address_line_1" VARCHAR,   -- String addressLine1
  "address_line_2" VARCHAR,   -- String addressLine2
  "city" VARCHAR,             -- String city
  "country_code" VARCHAR(3),  -- String countryCode
  "state" VARCHAR,            -- String state
  "zip_code" VARCHAR          -- String zipCode 
) ;

-- Entity: Account @ account

CREATE TABLE IF NOT EXISTS "account" (
  "id" SERIAL PRIMARY KEY,    -- int id
  "address" BIGINT,           -- Address address @ address.id
  "creation_time" TIMESTAMP,  -- DateTime creationTime
  "email" VARCHAR(200),       -- String email
  "password_hash" VARCHAR,    -- String passwordHash
  CONSTRAINT "account__email__unique" UNIQUE ("email"),
  CONSTRAINT "account__address__fkey" FOREIGN KEY ("address") REFERENCES "address"("id") ON UPDATE CASCADE  -- address @ address.id 
) ;

```

To list the current tables:

```
postgres=# \d
               List of relations
 Schema |      Name      |   Type   |  Owner   
--------+----------------+----------+----------
 public | account        | table    | postgres
 public | account_id_seq | sequence | postgres
 public | address        | table    | postgres
 public | address_id_seq | sequence | postgres
(4 rows)
```

Now you have a running database that your API can connect and use.

## Generating Tables SQL

The script `bin/generate_tables_sql.dart` can generate the tables
SQL based into an `APIConfig` file, like `api-local-postgres.yaml` and
`api-local-mysql.yaml`.

See `generate-tables-sql.sh`, that will generate the files:
- `db-tables-postgres-generated.sql`
- `db-tables-mysql-generated.sql`

## Calling the API (HTTP)

To add an `Account`:

- http://localhost:8080/account/register?email=joe@mail.com&password=123&countryCode=US&state=NY&city=Buffalo

To select `Account`s by `Address.state`:

- http://localhost:8080/account/byState?state=NY

*See the class `ModuleAccount` for more routes.*


## Bones_API

See the package `bones_api` for more information:

- https://pub.dev/packages/bones_api

