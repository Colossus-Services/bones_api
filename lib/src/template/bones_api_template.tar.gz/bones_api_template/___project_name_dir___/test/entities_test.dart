import 'package:___project_name_dir___/___project_name_dir___.dart';
import 'package:test/test.dart';

void main() {
  group('Entities', () {
    setUpAll(() {
      Account$reflection.boot();
    });

    test('Account', () {
      var address = Address(
          'US',
          'NY',
          'City',
          'Street 1',
          '101',
          '123456');

      var account = Account('foo@mail.com', '12345678', address);
      expect(account.email, equals('foo@mail.com'));
      expect(account.checkPassword('12345678'), isTrue);
      expect(account.checkPassword('1234'), isFalse);

      expect(account.address, isNotNull);
      expect(account.address.state, equals('NY'));

      expect(account.reflection.getField('email'), equals('foo@mail.com'));
    });

    test('Address', () {
      var address = Address(
          'BR',
          'SP',
          'City',
          'Street 1',
          '404',
          '500400300');

      expect(address.countryCode, equals('BR'));
      expect(address.state, equals('SP'));

      expect(address.reflection.getField('countryCode'), equals('BR'));
      expect(address.reflection.getField('state'), equals('SP'));
    });
  });
}
