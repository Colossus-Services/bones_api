import 'package:___project_name_dir___/___project_name_dir____repositories.dart';
import 'package:___project_name_dir___/___project_name_dir____root.dart';
import 'package:test/test.dart';

import 'tests_utils.dart';

var samples = {
  'address': [
    {
      'id': 212,
      'countryCode': 'US',
      'state': 'NY',
      'city': 'New York',
      'addressLine1': 'Main Street',
      'addressLine2': '100',
      'zipcode': 100440101,
    }
  ],
  'account': [
    {
      'id': 87,
      'address': 212,
      'email': 'joe@gmail.com',
      'passwordHash':
          '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92',
      'creationDate': '2021-12-07 14:41:09.669704',
    }
  ],
};

var credential = APICredential('joe@gmail.com', passwordHash: '123456');

void main() async {
  group('MyAPIRoot/account', () {
    late final APIRootStarter<MyAPIRoot> apiRootStarter;
    late final MyAPIRoot api;

    setUpAll(() async {
      apiRootStarter = await getAPIRootStarter();
      api = await apiRootStarter.getAPIRootStarted();
      print(api);

      var repositoryProvider = APIEntityRepositoryProvider();

      var results = await repositoryProvider.storeAllFromJson(samples);

      var resultAddress = results['address'] as List;
      var resultAccount = results['account'] as List;
      
      expect(resultAddress.length, equals(1));
      expect(resultAccount.length, equals(1));
    });

    tearDownAll(() async {
      await apiRootStarter.stop();
    });

    test('register', () async {
      var email = 'joe2@gmail.com';
      var password = '123456';
      var countryCode = 'US';
      var state = 'CA';
      var city = 'Los Angeles';
      var addressLine1 = 'Alanda Place';
      var addressLine2 = '1001';
      var zipCode = '90210';

      APIResponse ret = await api.call(APIRequest.get('account/register',
          parameters: {
            'email': email,
            'password': password,
            'countryCode': countryCode,
            'state': state,
            'city': city,
            'addressLine1': addressLine1,
            'addressLine2': addressLine2,
            'zipCode': zipCode,
          },
          credential: credential));

      print(ret.status);
      print(ret.payload);

      var account = ret.payload as Account;
      expect(account.email, email);
    }, skip: false);

    test('edit', () async {
      var accountId = 87;
      
      var addressLine1 = 'Alden Drive';
      var addressLine2 = '101';
      var zipCode = '90210';

      APIResponse ret = await api.call(APIRequest.get('account/edit',
          parameters: {
            'id': accountId,
            'addressLine1': addressLine1,
            'addressLine2': addressLine2,
            'zipCode': zipCode,
          },
          credential: credential));

      print(ret.status);
      print(ret.payload);

      var account = ret.payload as Account;
      expect(account.email, 'joe@gmail.com');
      expect(account.address.addressLine1, addressLine1);
      expect(account.address.addressLine2, addressLine2);
      expect(account.address.zipCode, zipCode);
    }, skip: false);

  }, skip: false);
}
