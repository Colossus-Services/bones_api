import 'package:bones_api/bones_api_logging.dart';
import 'package:bones_api/bones_api_test_postgres.dart';
import 'package:bones_api/bones_api_test_mysql.dart';
import 'package:logging/logging.dart' as logging;
import 'package:___project_name_dir___/___project_name_dir____root.dart';

final _log = logging.Logger('TestConfig');

const String propertyDbType = 'bones_api.test.db.type';

const Map<String, dynamic> apiConfigMemory = <String, dynamic>{
  'db': {
    'memory': {},
  },
};

const Map<String, dynamic> apiConfigPostgres = <String, dynamic>{
  'db': {
    'postgres': {
      'port': -5432,
      'database': 'dev_postgres',
      'username': 'postgres',
      'password': '123456',
      'populate': {
        'generateTables': true,
      }
    },
  },
};

const Map<String, dynamic> apiConfigMysql = <String, dynamic>{
  'db': {
    'mysql': {
      'port': -3306,
      'database': 'dev_mysql',
      'username': 'mysql',
      'password': '123456',
      'populate': {
        'generateTables': true,
      }
    },
  },
};

FutureOr<APIRootStarter<MyAPIRoot>> getAPIRootStarter() {
  var apiTestConfig = getAPITestConfig();
  return apiTestConfig
      .createAPIRootStarter((apiConfig) => MyAPIRoot(apiConfig: apiConfig));
}

APITestConfig getAPITestConfig() {
  _log.handler.logToConsole();

  var dbType = APIPlatform.get()
      .getProperty(propertyDbType, defaultValue: 'memory')!
      .trim()
      .toLowerCase();

  _log.info('** DB TYPE: $dbType');

  var containerPrefix = 'dev_test_$dbType';

  if (dbType == 'postgres') {
    return APITestConfigDockerPostgreSQL(apiConfigPostgres,
        containerNamePrefix: containerPrefix);
  } else if (dbType == 'mysql') {
    return APITestConfigDockerMySQL(apiConfigMysql,
        containerNamePrefix: containerPrefix);
  } else {
    return APITestConfigDBMemory(apiConfigMemory);
  }
}

void showResponse(APIResponse<dynamic> ret) {
  _log.info(ret);
  _log.info('-- Status: ${ret.status}');
  _log.info('-- Error: ${ret.error}');
  _log.info('-- Payload: ${ret.payload}');
  _log.info('-- payloadMimeType: ${ret.payloadMimeType}');
}

