import 'package:___project_name_dir___/___project_name_dir____repositories.dart';
import 'package:___project_name_dir___/___project_name_dir____root.dart';
import 'package:test/test.dart';

import 'tests_utils.dart';

var credential = APICredential('joe@gmail.com', passwordHash: '123456');

void main() async {
  group('MyAPIRoot/address', () {
    late final APIRootStarter<MyAPIRoot> apiRootStarter;
    late final MyAPIRoot api;

    setUpAll(() async {
      apiRootStarter = await getAPIRootStarter();
      api = await apiRootStarter.getAPIRootStarted();
      print(api);

      var repositoryProvider = APIEntityRepositoryProvider();
      print(repositoryProvider);
    });

    tearDownAll(() async {
      await apiRootStarter.stop();
    });

    test('register', () async {
      var countryCode = 'US';
      var state = 'NY';
      var city = 'New York';
      var addressLine1 = 'Main Street';
      var addressLine2 = '101';
      var zipCode = '100440101';

      APIResponse ret = await api.call(APIRequest.get('address/register',
          parameters: {
            'countryCode': countryCode,
            'state': state,
            'city': city,
            'addressLine1': addressLine1,
            'addressLine2': addressLine2,
            'zipCode': zipCode,
          },
          credential: credential));

      print(ret.status);
      print(ret.payload);

      var address = ret.payload as Address;
      
      expect(address.state, state);
      expect(address.city, city);
      expect(address.zipCode, zipCode);
    }, skip: false);

  }, skip: false);
}
