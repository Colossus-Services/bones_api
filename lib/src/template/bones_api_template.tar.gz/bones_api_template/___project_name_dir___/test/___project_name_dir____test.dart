import 'package:___project_name_dir___/___project_name_dir____root.dart';
import 'package:test/test.dart';

import 'tests_utils.dart';

void main() {
  group('MyAPIRoot', () {
    late final APIRootStarter<MyAPIRoot> apiRootStarter;
    late final MyAPIRoot api;

    setUpAll(() async {
      apiRootStarter = await getAPIRootStarter();
      api = await apiRootStarter.getAPIRootStarted();
      print(api);
    });

    tearDownAll(() async {
      await apiRootStarter.stop();
    });

    test('info/info', () async {
      var ret = await api.call(APIRequest.get('API-INFO'));
      
      expect(ret.status, equals(APIResponseStatus.OK));

      APIRootInfo info = ret.payload;
      expect(info.name, equals('___project_name_dir___'));
      expect(info.modules.length, greaterThan(2));
    });
  });
}
