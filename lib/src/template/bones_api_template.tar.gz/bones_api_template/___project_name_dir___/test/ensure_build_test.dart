@TestOn('vm')
@Tags(['build', 'slow'])
import 'package:build_verify/build_verify.dart';
import 'package:test/test.dart';

// Checks if generated code is built
// (like `reflection_factory` `.g.dart` files)
// and if they are committed to git.
// 
// Uncommitted changes will make this test fail.
// 
// You can skip this test with:
// 
// ```
// $> dart test -x build
// ```
// 
void main() {
  test('ensure_build', expectBuildClean);
}
