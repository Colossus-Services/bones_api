#!/bin/bash

## Ensure that the project is resolved:
dart pub get

## Ensure that `bones_api` CLI is activated.
dart pub global activate bones_api

## Serve the `MyAPIRoot`, with HotReload (`-r`) and auto-build of reflections (`-b`).
bones_api serve -d . -c MyAPIRoot -i ./api-local.yaml -r -b

## CLI help:
# bones_api serve -h
