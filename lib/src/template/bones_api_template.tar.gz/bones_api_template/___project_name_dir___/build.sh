#!/bin/bash

## Ensure that the project is resolved:
dart pub get

## Build the reflection files:
dart run build_runner build

## Ensure that the project is formatted.
dart format .

## Show any analysis issue:
dart analyze .
