import 'package:bones_api/bones_api.dart';

import 'api_repositories.dart';
import 'module_account.dart';
import 'module_address.dart';
import 'module_info.dart';

class MyAPIRoot extends APIRoot {
  MyAPIRoot({dynamic apiConfig})
      : super('___project_name_dir___', '___project_version___',
            apiConfig: apiConfig);

  APIEntityRepositoryProvider? _apiEntityRepositoryProvider;

  @override
  List<EntityRepositoryProvider> loadEntityRepositoryProviders() =>
      <EntityRepositoryProvider>[
        _apiEntityRepositoryProvider ??= APIEntityRepositoryProvider()
      ];

  @override
  Set<APIModule> loadModules() => {
    ModuleInfo(this),
    ModuleAddress(this),
    ModuleAccount(this),
  };

  @override
  String? get defaultModuleName => 'info';

  @override
  void onClose() {
    _apiEntityRepositoryProvider?.close();
  }
}
