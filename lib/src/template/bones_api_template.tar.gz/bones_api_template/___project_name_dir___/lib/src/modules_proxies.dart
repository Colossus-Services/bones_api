import 'package:bones_api/bones_api.dart';
import 'package:mercury_client/mercury_client.dart';

import 'api_entities.dart';

part 'reflection/modules_proxies.g.dart';

@Target({TargetKind.classType})
@EnableReflection()
class MyModuleProxy extends APIModuleProxy {
  const MyModuleProxy(String moduleClassName)
      : super(moduleClassName,
            libraryPath: 'package:___project_name_dir___/___project_name_dir____root.dart');
}

class MyModulesProxies {
  final HttpClient httpClient;

  MyModulesProxies(this.httpClient);

  late final AddressModuleProxy addressModule = AddressModuleProxy(httpClient);

  late final AccountModuleProxy accountModule = AccountModuleProxy(httpClient);
}

@MyModuleProxy('ModuleAddress')
class AddressModuleProxy extends APIModuleHttpProxy {
  AddressModuleProxy(HttpClient httpClient)
      : super(httpClient, moduleRoute: 'address') {
    Address$reflection.boot();
  }
}

@MyModuleProxy('ModuleAccount')
class AccountModuleProxy extends APIModuleHttpProxy {
  AccountModuleProxy(HttpClient httpClient)
      : super(httpClient, moduleRoute: 'account') {
    Account$reflection.boot();
  }
}
