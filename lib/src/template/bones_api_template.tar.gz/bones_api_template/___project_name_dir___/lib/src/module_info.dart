import 'package:bones_api/bones_api.dart';

class ModuleInfo extends APIModule {
  ModuleInfo(APIRoot apiRoot) : super(apiRoot, 'info');

  @override
  String? get defaultRouteName => '404';

  @override
  void configure() {
    routes.any('404', _notFound);
    routes.any('info', _info);
  }

  FutureOr<APIResponse<String>> _notFound(req) {
    return APIResponse.notFound(payload: 'NOT FOUND!: ${req.path}');
  }

  FutureOr<APIResponse<String>> _info(req) {
    var html = '''
    <h1>___project_name___</h1>
    Date: ${DateTime.now()}
    ''';

    return APIResponse.ok(html);
  }
}
