import 'package:bones_api/bones_api.dart';
import 'package:collection/collection.dart';

import 'api_entities.dart';
import 'api_repositories.dart';

part 'reflection/module_account.g.dart';

@EnableReflection()
class ModuleAccount extends APIModule {
  ModuleAccount(APIRoot apiRoot) : super(apiRoot, 'account');

  final AddressAPIRepository addressRepository = AddressAPIRepository();

  final AccountAPIRepository accountRepository = AccountAPIRepository();

  late final _MyAPISecurity _security;

  @override
  void configure() {
    routes.anyFrom(reflection);

    _security = _MyAPISecurity(accountRepository);
  }

  @override
  APISecurity get security => _security;

  Future<APIResponse<Account>> register(
      {required String email,
      required String password,
      required String countryCode,
      required String state,
      required String city,
      String? address1,
      String? address2,
      String? zipCode}) async {
    var address = Address(countryCode, state, city, address1 ?? '',
        address2 ?? '', zipCode ?? '');

    var account = Account(email, password, address);

    var stored = await accountRepository.store(account);

    print('stored: $stored');

    return stored != null
        ? APIResponse.ok(account)
        : APIResponse.error(error: "Can't store account");
  }

  Future<APIResponse<Account>> edit(
      {
      required int id,
      String? email,
      String? password,
      String? countryCode,
      String? state,
      String? city,
      String? addressLine1,
      String? addressLine2,
      String? zipCode}) async {
    var account = await accountRepository.selectByID(id);

    if (account == null) {
      return APIResponse.error(error: 'Invalid `Account` id: $id');
    }

    var address = account.address;

    if (email != null) account.email = email;
    if (password != null) account.passwordHash = Account.hashPassword(password);

    if (countryCode != null) address.countryCode = countryCode;
    if (state != null) address.state = state;
    if (addressLine1 != null) address.addressLine1 = addressLine1;
    if (addressLine2 != null) address.addressLine2 = addressLine2;
    if (zipCode != null) address.zipCode = zipCode;

    var stored = await accountRepository.store(account);

    print('stored: $stored');

    return stored != null
        ? APIResponse.ok(account)
        : APIResponse.error(error: "Can't edit `Account` id: $id");
  }

  Future<APIResponse<int>> count() async {
    var count = await accountRepository.length();
    return APIResponse.ok(count);
  }

  Future<APIResponse<Account?>> deleteByEmail(String email) async {
    var del = await accountRepository
        .deleteByQuery(' email == ? ', parameters: [email]);
    return APIResponse.ok(del.firstOrNull);
  }

  APIResponse byState(String state) {
    var sel = accountRepository.selectByAddressState(state);
    return APIResponse.ok(sel);
  }
}


class _MyAPISecurity extends APISecurity {
  final AccountAPIRepository accountRepository;

  _MyAPISecurity(this.accountRepository);

  @override
  Future<bool> checkCredentialPassword(APICredential credential) async {
    var account = await getAccountByCredential(credential);
    if (account == null) {
      return false;
    }

    var passOk = credential.checkPassword(account.passwordHash);
    return passOk;
  }

  @override
  FutureOr<Object?> getAuthenticationData(APICredential credential, Object? previousData) async {
    var account = await getAccountByCredential(credential);
    return Json.toJson(account, removeField: (k) => k == 'passwordHash');
  }

  @override
  FutureOr<List<APIPermission>> getCredentialPermissions(
      APICredential credential, List<APIPermission>? prevPermissiona) async {
    var account = await getAccountByCredential(credential);
    if (account == null) {
      return <APIPermission>[];
    }

    return <APIPermission>[];
  }

  Future<Account?> getAccountByCredential(APICredential credential) async {
    if (credential.usernameEntity is Account) {
      return credential.usernameEntity;
    }

    var account = await getAccountByEmail(credential.username);
    credential.usernameEntity = account;

    return account;
  }

  Future<Account?> getAccountByEmail(String? username) async {
    if (username == null) return null;
    var sel = await accountRepository.selectByEmail(username);
    var account = sel.firstOrNull;
    return account;
  }
}

