import 'package:bones_api/bones_api.dart';
import 'package:bones_api/bones_api_db_mysql.dart';
import 'package:bones_api/bones_api_db_postgre.dart';

import 'api_entities.dart';
import 'api_root.dart';

class APIEntityRepositoryProvider extends DBSQLEntityRepositoryProvider {
  static final APIEntityRepositoryProvider _instance =
      APIEntityRepositoryProvider._();

  APIEntityRepositoryProvider._() {
    // Boot the adapters that you want to use:
    DBPostgreSQLAdapter.boot();
    DBMySQLAdapter.boot();
  }

  // Singleton instance:
  factory APIEntityRepositoryProvider() => _instance;

  static MyAPIRoot? get apiRoot => APIRoot.getByType<MyAPIRoot>();

  @override
  Map<String, dynamic> get adapterConfig => apiRoot?.apiConfig['db'];

  @override
  List<DBSQLEntityRepository> buildRepositories(DBSQLAdapter adapter) {
    return <DBSQLEntityRepository>[
      DBSQLEntityRepository<Address>(
          adapter, 'address', Address$reflection().entityHandler),
      DBSQLEntityRepository<Account>(
          adapter, 'account', Account$reflection().entityHandler),
    ];
  }
}

class AddressAPIRepository extends APIRepository<Address> {
  AddressAPIRepository() : super(provider: APIEntityRepositoryProvider());

  FutureOr<Iterable<Address>> selectByState(String state) {
    return selectByQuery(' state == ? ', parameters: {'state': state});
  }
}

class AccountAPIRepository extends APIRepository<Account> {
  AccountAPIRepository() : super(provider: APIEntityRepositoryProvider());

  FutureOr<Iterable<Account>> selectByEmail(String email) {
    return selectByQuery(' email == ? ',
        parameters: {'email': email}, limit: 1);
  }

  FutureOr<Iterable<Account>> selectByAddressState(String state) {
    return selectByQuery(' address.state == ? ', parameters: [state]);
  }
}
