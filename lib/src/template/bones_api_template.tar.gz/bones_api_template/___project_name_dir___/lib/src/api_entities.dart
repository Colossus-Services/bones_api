import 'dart:convert';

import 'package:bones_api/bones_api.dart';
import 'package:crypto/crypto.dart';

part 'reflection/api_entities.g.dart';

@EnableReflection()
class Address {
  int? id;

  @EntityField.maximum(3)
  @EntityField.regexp(r'^\w{2,3}$')
  String countryCode;

  String state;

  String city;

  String addressLine1;
  String addressLine2;

  String zipCode;

  Address(this.countryCode, this.state, this.city, this.addressLine1,
      this.addressLine2, this.zipCode,
      {this.id});

  Address.create() : this('', '', '', '', '', '');
}

@EnableReflection()
class Account {
  int? id;

  @EntityField.unique()
  @EntityField.maximum(200)
  String email;

  String passwordHash;

  Address address;

  DateTime creationTime;

  Account(this.email, String passwordOrHash, this.address,
      {this.id, DateTime? creationTime})
      : passwordHash = hashPassword(passwordOrHash),
        creationTime = creationTime ?? DateTime.now();

  Account.create() : this('', '', Address.create());

  bool checkPassword(String passwordOrHash) {
    return passwordHash == hashPassword(passwordOrHash);
  }

  static final RegExp _regExpHEX = RegExp(r'ˆ(?:[0-9a-fA-F]{2})+$');

  static bool isHashedPassword(String password) {
    return password.length == 64 && _regExpHEX.hasMatch(password);
  }

  static String hashPassword(String password) {
    if (isHashedPassword(password)) {
      return password;
    }

    var bytes = utf8.encode(password);
    var digest = sha256.convert(bytes);
    var hash = digest.toString();

    return hash;
  }
}

