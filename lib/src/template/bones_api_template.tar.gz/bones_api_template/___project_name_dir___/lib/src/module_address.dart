import 'package:bones_api/bones_api.dart';

import 'api_entities.dart';
import 'api_repositories.dart';

part 'reflection/module_address.g.dart';

@EnableReflection()
class ModuleAddress extends APIModule {
  ModuleAddress(APIRoot apiRoot) : super(apiRoot, 'address');

  final AddressAPIRepository addressRepository = AddressAPIRepository();

  @override
  void configure() {
    routes.anyFrom(reflection);
  }

  Future<APIResponse<Address>> register(
      {required String countryCode,
      required String state,
      required String city,
      String? addressLine1,
      String? addressLine2,
      String? zipCode}) async {
    var address = Address(countryCode, state, city, addressLine1 ?? '',
        addressLine2 ?? '', zipCode ?? '');

    var stored = await addressRepository.store(address);

    print('stored: $stored');

    return stored != null
        ? APIResponse.ok(address)
        : APIResponse.error(error: "Can't register address");
  }

  Future<APIResponse<Address>> edit(
      {required int id,
      String? countryCode,
      String? state,
      String? city,
      String? addressLine1,
      String? addressLine2,
      String? zipCode}) async {
  	var address = await addressRepository.selectByID(id);

    if (address == null) {
      return APIResponse.error(error: 'Invalid `Address` id: $id');
    }

    if (countryCode != null) address.countryCode = countryCode;
    if (state != null) address.state = state;
    if (city != null) address.city = city;
    if (addressLine1 != null) address.addressLine1 = addressLine1;
    if (addressLine2 != null) address.addressLine2 = addressLine2;
    if (zipCode != null) address.zipCode = zipCode;

    var stored = await addressRepository.store(address);

    print('stored: $stored');

    return stored != null
        ? APIResponse.ok(address)
        : APIResponse.error(error: "Can't edit `Address` id: $id");
  }

  Future<APIResponse<int>> count() async {
    var count = await addressRepository.length();
    return APIResponse.ok(count);
  }

  Future<APIResponse<List<Address>>> byState(String state) async {
    var sel = await addressRepository.selectByState(state);
    return APIResponse.ok(sel.toList());
  }
  
}
