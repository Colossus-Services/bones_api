/// Library ___project_name___ Repositories.
library ___project_name_dir___.repositories;

export '___project_name_dir___.dart';

export 'src/api_repositories.dart';
