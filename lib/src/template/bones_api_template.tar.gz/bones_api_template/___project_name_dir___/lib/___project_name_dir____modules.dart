/// Library ___project_name___ Modules.
library ___project_name_dir___.modules;

export '___project_name_dir___.dart';

export 'src/module_account.dart';
export 'src/module_address.dart';
export 'src/module_info.dart';
