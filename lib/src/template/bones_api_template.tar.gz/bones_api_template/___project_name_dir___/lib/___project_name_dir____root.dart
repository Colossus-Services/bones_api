/// Library ___project_name___ APIRoot.
library ___project_name_dir___.root;

export 'package:bones_api/bones_api.dart';

export '___project_name_dir___.dart';

export 'src/api_root.dart';
