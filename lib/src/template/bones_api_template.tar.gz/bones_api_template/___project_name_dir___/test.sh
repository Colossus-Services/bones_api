#!/bin/bash

## Ensure that the project is resolved:
dart pub get

## Run tests skipping tests tagged
## with `build` (ensure_build_test.dart)
dart test -x build
